#include "DHT11.h"

uint8_t Hum_H, Hum_L, Tem_H, Tem_L;
 
void DHT11_Init(void)//DHT11 OUT 引脚初始化 PA1
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Enable GPIO clock */
  /* 使能GPIOA时钟 PA1 */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	/* Configure PA1 in output pushpull mode */
  /* 配置PA1 推挽输出模式 */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void DHT11_Mode_Out_PP(void)//PA1输出模式
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* Configure PA1 in output pushpull mode */
  /* 配置PA1 推挽输出模式 */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void DHT11_Mode_IPU(void)//PA1输入模式
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* Configure PA1 in Pull-up input mode */
  /* 配置PA1 上拉输入模式 */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void DHT11_Start(void)//DHT11开始信号
{
	uint16_t Time;
	
	/* 主机拉低：PA1输出低电平信号不低于18ms */
	DHT11_Mode_Out_PP();//PA1输出模式
	DHT11_PA1_OUT(0);//PA1输出低电平
	Delay_us(20000);//拉低信号20ms
	
	/* 主机拉高：PA1输出高电平信号20-40ms */
	DHT11_PA1_OUT(1);//PA1输出高电平
	Delay_us(30);//拉高信号30us
	
	
	DHT11_Mode_IPU();//PA1输入模式
	
	/* DHT11响应信号 */
	/* 
		80us低电平信号
	*/
	Time = 80;
	while((!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)) && (Time > 0))
	{
		Time--;
		Delay_us(1);
	}
	/* 
		80us高电平信号
	*/
	Time = 80;
	while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) && (Time > 0))
	{
		Time--;
		Delay_us(1);
	}
}

uint8_t DHT11_Read_Byte(void)//读取DHT11数据
{
	uint16_t i;
	uint8_t Data = 0;
	uint16_t Time;
	
	DHT11_Mode_IPU();//PA1输入模式
	
	/* 接收一个Byte数据 */
	for(i = 0; i < 8; i++)
	{
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 0);//等待50us低电平间隙信号发送完成
		
		Delay_us(40);//区分数据为是'0'还是'1'
	
		Data <<= 1;
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))//如果40us过后还是高电平，则数据为1; 反之,数据为0
			Data += 1;
		
		Time = 50;
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) && (Time > 0))//等待上一个数据发送完毕
		{
			Time--;
			Delay_us(1);
		}		
	}
	
	return Data;
}

void DHT11_Read(void)//读取DHT11完整信息
{
	uint8_t Hum_H_temp, Hum_L_temp, Tem_H_temp, Tem_L_temp, Check_Sum;
	
	DHT11_Start();//DHT11开始信号
	
	Hum_H_temp = DHT11_Read_Byte();//湿度整数
	Hum_L_temp = DHT11_Read_Byte();//湿度小数
	Tem_H_temp = DHT11_Read_Byte();//温度整数
	Tem_L_temp = DHT11_Read_Byte();//温度小数
	Check_Sum  = DHT11_Read_Byte();//校验和
	
	DHT11_Mode_Out_PP();//PA1输出模式
	DHT11_PA1_OUT(1);//拉高电平 进入空闲状态

	if((Hum_H_temp + Hum_L_temp + Tem_H_temp + Tem_L_temp) == Check_Sum)//数据校验 获取正确数据
	{
		Hum_H = Hum_H_temp;
		Hum_L = Hum_L_temp;
		Tem_H = Tem_H_temp;
		Tem_L = Tem_L_temp;
	}
}
