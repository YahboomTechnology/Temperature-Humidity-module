#ifndef __DHT11_H__
#define __DHT11_H__

#include "stm32f10x.h"
#include "SysTick.h"

#define DHT11_PA1_OUT(A)	GPIO_WriteBit(GPIOA, GPIO_Pin_1, (BitAction)(A))

extern uint8_t Hum_H, Hum_L, Tem_H, Tem_L;

void DHT11_Init(void);///DHT11 OUT 引脚初始化 PA1
void DHT11_Read(void);////读取DHT11完整信息

#endif
